public class Calculator {
	
	private String operator;
	private int result;
	private int operand,operand2;
	
	/**Creates  a new calculator instance*/
	public Calculator() {
		this.operator = "";
		this.result = 0;
		this.operand = -1;
		this.operand = -1;
	}
	
	/** returns the operator */
	public String getOperator(){
		return this.operator;
	}
	
	/**returns result*/
	public int getResult(){
		System.out.println("resultatet �r:"+result);
		return this.result;
	}
	
	public int getOperand(){
		return this.operand;	
	}
	
	/**buttonpress*/ 
	public void numberButtonPressed(int number){
	  this.operand = this.operand*10 + number;
	}
	
	/**clears all including operand and result*/
	public void clear(){
		this.operator = "";
		this.result = 0;
		this.operand = 0;
		   System.out.println("screen clear!!!");
	}
	
	public void plus(){
	   this.result = this.operand;
	   this.operator = "+";
	   System.out.println("+");
	}
	
	public void minus(){
		result = operand;
		operator = "-";
		   System.out.println("-");
	}
	
	public void multi(){
		result = operand;
		operator = "*";
		   System.out.println("*");
	}
	
	public void equals(){
		if (operator.equals("*")){
			result= result * operand;
		}else if(operator.equals("-")){
			result= result - operand;
		}else if(operator.equals("+")){
			result= result + operand;
		}
		//operand = 0;
	}

	public void setOperand(int _nummer) {
			operand = _nummer;
			System.out.println("operand1: " + operand);
	}

}