
public class Constants {

	public static final int minSize = 8;
	public static int maxSize = 28;
	public static int minPrice = 0;
	public static int maxPrice = 30000;
	
	
	public static final
	String[]aloudcolors = new String[]{"blue","green","pink","gold","black","yellow","silver","purple","white","red"
		
	};
	
}



