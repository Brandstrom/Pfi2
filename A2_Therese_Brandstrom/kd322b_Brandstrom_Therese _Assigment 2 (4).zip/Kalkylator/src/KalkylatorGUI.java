import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class KalkylatorGUI extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					KalkylatorGUI frame = new KalkylatorGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public KalkylatorGUI() {
		
		final Calculator calc; // deklarera instans veriabel
		 calc= new Calculator(); // skapa instans new
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 360, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(28, 11, 285, 105);
		contentPane.add(scrollPane);
		
		final JTextArea txtrDisplay = new JTextArea();

		scrollPane.setViewportView(txtrDisplay);
		
		JButton button_1 = new JButton("1");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				calc.setOperand(1);
				txtrDisplay.append("1");
			}
		});
		button_1.setBounds(28, 145, 89, 23);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			calc.setOperand(2);
			txtrDisplay.append("2");

			}
		});
		button_2.setBounds(127, 145, 89, 23);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("3");
		button_3.setBounds(226, 145, 89, 23);
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calc.setOperand(3);
				txtrDisplay.append("3");

			}
		});
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("4");
		button_4.setBounds(28, 179, 89, 23);
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calc.setOperand(4);	
				txtrDisplay.append("4");

			}
		});
		contentPane.add(button_4);
		
		JButton button_5 = new JButton("5");
		button_5.setBounds(127, 179, 89, 23);
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calc.setOperand(5);
				txtrDisplay.append("5");

			}
		});
		contentPane.add(button_5);
		
		JButton button_6 = new JButton("6");
		button_6.setBounds(226, 179, 89, 23);
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calc.setOperand(6);
				txtrDisplay.append("6");

			}
		});
		contentPane.add(button_6);
		
		JButton button_7 = new JButton("7");
		button_7.setBounds(28, 213, 89, 23);
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calc.setOperand(7);
				txtrDisplay.append("7");

			}
		});
		contentPane.add(button_7);
		
		JButton button_8 = new JButton("8");
		button_8.setBounds(127, 213, 89, 23);
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calc.setOperand(8);
				txtrDisplay.append("8");

			}
		});
		contentPane.add(button_8);
		
		JButton button_9 = new JButton("9");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calc.setOperand(9);
				txtrDisplay.append("9");

			}
		});
		button_9.setBounds(226, 213, 89, 23);
		contentPane.add(button_9);
		
		JButton button_0 = new JButton("0");
		button_0.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				calc.setOperand(0);
				txtrDisplay.append("0");

				}
			
		});
		button_0.setBounds(28, 250, 89, 23);
		contentPane.add(button_0);
		
		JButton button_plus = new JButton("+");
		button_plus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			calc.plus();
			//calc.setOperator("+");
			txtrDisplay.append("+");

			}
		});
		button_plus.setBounds(127, 250, 89, 23);
		contentPane.add(button_plus);
		
		JButton button_minus = new JButton("-");
		button_minus.setBounds(226, 250, 89, 23);
		button_minus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calc.minus();
			//calc.setOperator("-");
				txtrDisplay.append("-");

			}
		});
		contentPane.add(button_minus);
		
		JButton button_multi = new JButton("*");
		button_multi.setBounds(127, 284, 89, 23);
		button_multi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calc.multi();
				//calc.setOperator("*");
				txtrDisplay.append("*");

			}
		});
		contentPane.add(button_multi);
		
		
		
		JButton button = new JButton("=");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				calc.equals();
				txtrDisplay.setText(Integer.toString(calc.getResult()));
		
			}
		});
		button.setBounds(127, 343, 89, 23);
		contentPane.add(button);
		
		JButton btnC = new JButton("C");
		btnC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0)
			{
				calc.clear();
				txtrDisplay.setText("");
			}
		});
		btnC.setBounds(127, 318, 89, 23);
		contentPane.add(btnC);
	}
}
